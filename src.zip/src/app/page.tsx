import TaxWebsite from '../components/TaxWebsite';

export default function Home() {
  return <TaxWebsite />;
}